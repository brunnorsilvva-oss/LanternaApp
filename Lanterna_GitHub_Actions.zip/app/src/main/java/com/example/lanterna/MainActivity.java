package com.example.lanterna;

import android.app.Activity;
import android.os.Bundle;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    private CameraManager cameraManager;
    private String cameraId;
    private boolean isOn = false;
    private Button button;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);

        try {
            String[] ids = cameraManager.getCameraIdList();
            if (ids.length > 0) cameraId = ids[0];
        } catch (CameraAccessException e) {
            cameraId = null;
        }

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(40, 40, 40, 40);

        status = new TextView(this);
        status.setText("Lanterna desligada");
        status.setTextSize(22);
        status.setGravity(Gravity.CENTER);
        status.setTextColor(Color.DKGRAY);

        button = new Button(this);
        button.setText("LIGAR LANTERNA");
        button.setTextSize(18);

        layout.addView(status);
        layout.addView(button);

        button.setOnClickListener(v -> toggleFlash());
        setContentView(layout);
    }

    private void toggleFlash() {
        if (cameraId == null) {
            status.setText("Flash não disponível");
            return;
        }

        try {
            isOn = !isOn;
            cameraManager.setTorchMode(cameraId, isOn);
            status.setText(isOn ? "Lanterna ligada" : "Lanterna desligada");
            button.setText(isOn ? "DESLIGAR LANTERNA" : "LIGAR LANTERNA");
        } catch (CameraAccessException | IllegalArgumentException e) {
            status.setText("Não foi possível controlar o flash");
            isOn = false;
            button.setText("LIGAR LANTERNA");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isOn && cameraId != null) {
            try {
                cameraManager.setTorchMode(cameraId, false);
            } catch (Exception ignored) {}
            isOn = false;
        }
    }
}
