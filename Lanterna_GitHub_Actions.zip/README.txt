PROJETO ANDROID - LANTERNA

Este projeto liga e desliga o flash do aparelho usando a API Camera2.

Como usar:
1. Abra a pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Conecte um aparelho Android compatível.
4. Execute o projeto.
5. Toque no botão para ligar/desligar a lanterna.

Observação:
O funcionamento depende de o aparelho possuir flash/lanterna compatível.
